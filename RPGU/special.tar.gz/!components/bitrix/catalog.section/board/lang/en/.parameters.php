<?
$MESS["IBLOCK_LINE_ELEMENT_COUNT"] = "Elements Per Table Row";
$MESS["IBLOCK_DETAIL_PAGE_URL"] = "Hide Details Link";
?>