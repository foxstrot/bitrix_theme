<?
$MESS["MFP_SEND_EMAIL"] = "Send New Element Notification E-mail";
$MESS["MFP_EMAIL_TO"] = "Destination E-mail Address";
$MESS["MFP_EMAIL_SUBJECT"] = "Subject";
$MESS["MFP_EMAIL_SUBJECT_DESC"] = "A reader news item has been submitted";
$MESS["MFP_EMAIL_TEMPLATES"] = "E-mail Templates";
?>