<?
$MESS["MFP_SEND_EMAIL"] = "Отправлять письмо с информацией о добавлении элемента";
$MESS["MFP_EMAIL_TO"] = "E-mail, на который будет отправлено письмо";
$MESS["MFP_EMAIL_SUBJECT"] = "Тема письма";
$MESS["MFP_EMAIL_SUBJECT_DESC"] = "Добавлена народная новость";
$MESS["MFP_EMAIL_TEMPLATES"] = "Почтовые шаблоны для отправки письма";
?>