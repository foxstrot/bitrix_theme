<?
$MESS ['IBLOCK_ADD_LIST_TITLE'] = "My elements";
$MESS ['IBLOCK_ADD_LIST_EMPTY'] = "You did not add any elements";
$MESS ['IBLOCK_ADD_LIST_EDIT'] = "edit";
$MESS ['IBLOCK_ADD_LIST_DELETE'] = "delete";
$MESS ['IBLOCK_ADD_LIST_DELETE_CONFIRM'] = "Are you sure you want to delete element #ELEMENT_NAME#?";
$MESS ['IBLOCK_ADD_LINK_TITLE'] = "Add";
$MESS ['IBLOCK_LIST_CANT_ADD_MORE'] = "You can not add new elements";
?>