<?
$MESS ['IBLOCK_ADD_LIST_TITLE'] = "Мои элементы";
$MESS ['IBLOCK_ADD_LIST_EMPTY'] = "Вы не добавляли никаких элементов";
$MESS ['IBLOCK_ADD_LIST_EDIT'] = "редактировать";
$MESS ['IBLOCK_ADD_LIST_DELETE'] = "удалить";
$MESS ['IBLOCK_ADD_LIST_DELETE_CONFIRM'] = "Вы действительно хотите удалить элемент #ELEMENT_NAME#?";
$MESS ['IBLOCK_ADD_LINK_TITLE'] = "Добавить";
$MESS ['IBLOCK_LIST_CANT_ADD_MORE'] = "Вы не можете добавлять новые элементы";
?>