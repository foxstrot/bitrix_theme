<?
$MESS ['IBLOCK_FORM_SUBMIT'] = "Save";
$MESS ['IBLOCK_FORM_APPLY'] = "Apply";
$MESS ['IBLOCK_FORM_RESET'] = "Reset";
$MESS ['IBLOCK_FORM_BACK'] = "List";

$MESS ['IBLOCK_FORM_DATE_FORMAT'] = "Format: ";

$MESS ['IBLOCK_FORM_FILE_NAME'] = "File";
$MESS ['IBLOCK_FORM_FILE_SIZE'] = "Size";
$MESS ['IBLOCK_FORM_FILE_DOWNLOAD'] = "download";
$MESS ['IBLOCK_FORM_FILE_DELETE'] = "delete file";

$MESS ['IBLOCK_FORM_CAPTCHA_TITLE'] = "Anti-bot protection";
$MESS ['IBLOCK_FORM_CAPTCHA_PROMPT'] = "Please type symbols you see on the picture";
?>
