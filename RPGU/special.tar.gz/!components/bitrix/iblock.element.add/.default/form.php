<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$APPLICATION->IncludeComponent("bitrix:infoportal.element.add.form", "", $arParams, $component);
?>