<?if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true)die();?>
<div id="banner-left-two">
<?=$arResult["BANNER"];?>
</div>