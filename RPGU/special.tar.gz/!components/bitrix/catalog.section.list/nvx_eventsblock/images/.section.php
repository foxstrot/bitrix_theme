<?
$sSectionName="images";
?>