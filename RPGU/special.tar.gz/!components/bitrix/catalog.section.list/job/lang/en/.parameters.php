<?
$MESS["IBLOCK_TITLE"] = "Title";
?>