<?
$MESS["IBLOCK_TITLE"] = "Заголовок";
?>