<?
$MESS ['MENU_ITEM_ACCESS_DENIED'] = "Access denied";
?>