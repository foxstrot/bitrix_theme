<?
$MESS ['MENU_TREE_NAME'] = "Древовидное меню";
$MESS ['MENU_TREE_DESC'] = "Древовидное меню";
?>