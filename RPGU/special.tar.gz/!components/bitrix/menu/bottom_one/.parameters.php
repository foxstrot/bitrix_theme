<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED!==true) die();

$arTemplateParameters = array(
	"MENU_TITLE" => Array(
		"NAME" => GetMessage("MENU_TITLE"),
		"TYPE" => "TEXT",
		"DEFAULT" => "�������",
	),
);

?>