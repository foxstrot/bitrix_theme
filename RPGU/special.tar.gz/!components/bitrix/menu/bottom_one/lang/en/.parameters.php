<?
$MESS["MENU_TITLE"] = "Title";
?>