<?
$MESS["MENU_TITLE"] = "Заголовок";
?>