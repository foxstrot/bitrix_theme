<?
$MESS["MENU_NEWS_SECTION_EDIT"] = "Редактировать разделы новостей";
?>