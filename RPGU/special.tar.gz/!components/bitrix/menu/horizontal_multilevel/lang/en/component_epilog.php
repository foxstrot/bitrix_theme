<?
$MESS["MENU_NEWS_SECTION_EDIT"] = "Edit News Sections";
?>