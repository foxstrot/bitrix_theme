<?
$MESS["TH_DATE"] = "Дата";
$MESS["TH_EMPLOYER"] = "Зарплата";
$MESS["TH_POSITION"] = "Должность";
?>