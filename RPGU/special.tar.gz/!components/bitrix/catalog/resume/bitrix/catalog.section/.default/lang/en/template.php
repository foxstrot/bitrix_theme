<?
$MESS["TH_DATE"] = "Date";
$MESS["TH_EMPLOYER"] = "Salary";
$MESS["TH_POSITION"] = "Position";
?>