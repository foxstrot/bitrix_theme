<?
$MESS["CATALOG_DOWNLOAD"] = "Скачать";
$MESS["CATALOG_BACK"] = "Назад в раздел";
$MESS["JOB_REQUIREMENTS"] = "Информация";
$MESS["JOB_EMPLOYER"] = "Контакты";
$MESS["JOB_DESCRIPTION"] = "Описание";
?>