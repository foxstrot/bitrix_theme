<?
$MESS["CATALOG_DOWNLOAD"] = "Download";
$MESS["CATALOG_BACK"] = "Back to the section";
$MESS["JOB_REQUIREMENTS"] = "Profile:";
$MESS["JOB_EMPLOYER"] = "Contact:";
$MESS["JOB_DESCRIPTION"] = "Seeking:";
?>