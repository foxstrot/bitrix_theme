<?
$MESS ['CATALOG_COMPARE_ELEMENTS'] = "Compare item list";
$MESS ['CATALOG_COMPARE'] = "Compare";
$MESS ['CATALOG_DELETE'] = "Remove";
?>