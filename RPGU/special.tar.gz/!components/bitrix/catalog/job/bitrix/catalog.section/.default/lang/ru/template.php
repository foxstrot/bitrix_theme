<?
$MESS["TH_DATE"] = "Дата";
$MESS["TH_EMPLOYER"] = "Работодатель";
$MESS["TH_POSITION"] = "Должность";
$MESS["TH_REMUNERATION"] = "Зарплата";
?>