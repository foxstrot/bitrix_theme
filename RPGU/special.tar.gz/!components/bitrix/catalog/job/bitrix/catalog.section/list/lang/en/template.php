<?
$MESS["CATALOG_BUY"] = "Buy";
$MESS["CATALOG_ADD"] = "Add to cart";
$MESS["CATALOG_NOT_AVAILABLE"] = "(not available from stock)";
$MESS["CATALOG_TITLE"] = "Title";
?>