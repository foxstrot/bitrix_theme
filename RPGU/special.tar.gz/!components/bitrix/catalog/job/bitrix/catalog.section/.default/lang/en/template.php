<?
$MESS["TH_DATE"] = "Date";
$MESS["TH_EMPLOYER"] = "Employer";
$MESS["TH_POSITION"] = "Position";
$MESS["TH_REMUNERATION"] = "Salary";
?>