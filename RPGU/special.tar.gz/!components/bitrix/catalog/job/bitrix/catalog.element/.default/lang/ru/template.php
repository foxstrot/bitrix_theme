<?
$MESS["CATALOG_DOWNLOAD"] = "Скачать";
$MESS["CATALOG_BACK"] = "Назад в раздел";
$MESS["JOB_REQUIREMENTS"] = "Требования";
$MESS["JOB_EMPLOYER"] = "Работодатель";
$MESS["JOB_DESCRIPTION"] = "Описание";
?>