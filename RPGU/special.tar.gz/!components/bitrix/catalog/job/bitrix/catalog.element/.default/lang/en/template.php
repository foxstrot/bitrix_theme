<?
$MESS["CATALOG_DOWNLOAD"] = "Download";
$MESS["CATALOG_BACK"] = "Back to the section";
$MESS["JOB_REQUIREMENTS"] = "General:";
$MESS["JOB_EMPLOYER"] = "Employer:";
$MESS["JOB_DESCRIPTION"] = "Job Description:";
?>