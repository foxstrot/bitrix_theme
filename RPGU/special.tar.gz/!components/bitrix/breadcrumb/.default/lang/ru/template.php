<?
$MESS['BREADCRUMB_MAIN'] = 'На главную страницу';
?>