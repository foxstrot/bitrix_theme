<?
$MESS ['PROFILE_DATA_SAVED'] = "All changes saved";
$MESS["NAME"] = "First Name";
$MESS["LAST_NAME"] = "Last Name";
$MESS["SECOND_NAME"] = "Middle Name";
$MESS["NEW_PASSWORD_CONFIRM"] = "Confirm Password";
$MESS["NEW_PASSWORD_REQ"] = "New Password";
$MESS["MAIN_SAVE"] = "Save Profile";
$MESS["MAIN_PSWD"] = "Password";
?>