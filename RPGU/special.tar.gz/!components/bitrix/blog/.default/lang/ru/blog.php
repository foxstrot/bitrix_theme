<?
$MESS["BC_SEARCH_TAG"] = "Облако тегов";
?>