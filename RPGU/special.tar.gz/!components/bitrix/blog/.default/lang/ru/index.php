<?
$MESS ['BC_NEW_COMMENTS'] = "Последние комментарии";
$MESS ['BC_NEW_BLOGS'] = "Новые";
$MESS ['BC_POPULAR_BLOGS'] = "Популярные";
$MESS ['BC_NEW_BLOGS_MES'] = "Новые блоги";
$MESS ['BC_POPULAR_BLOGS_MES'] = "Популярные блоги";
$MESS ['BC_GROUPS'] = "Группы блогов";
$MESS ['BLOG_TITLE'] = "Блоги";
$MESS ['BLOG_CREATE_BLOG'] = "Создать свой блог";
$MESS ['BC_NEW_POSTS'] = "Последние";
$MESS ['BC_POPULAR_POSTS'] = "Популярные";
$MESS ['BC_COMMENTED_POSTS'] = "Обсуждаемые";
$MESS ['BC_NEW_POSTS_MES'] = "Последнее в блогах";
$MESS ['BC_POPULAR_POSTS_MES'] = "Популярные сообщения";
$MESS ['BC_COMMENTED_POSTS_MES'] = "Обсуждаемые сообщения";
$MESS ['BC_SEARCH_TAG'] = "Облако тегов";
$MESS ['BC_ALL_POSTS'] = "Просмотреть все сообщения";
$MESS ['BC_ALL_BLOGS'] = "Просмотреть все блоги";
?>
