<?
$MESS["BC_SEARCH_TAG"] = "Tag Cloud";
?>