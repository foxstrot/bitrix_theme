<?
$MESS ['BC_NEW_COMMENTS'] = "Recent comments";
$MESS ['BC_NEW_BLOGS'] = "New";
$MESS ['BC_POPULAR_BLOGS'] = "Popular";
$MESS ['BC_NEW_BLOGS_MES'] = "New blogs";
$MESS ['BC_POPULAR_BLOGS_MES'] = "Popular blogs";
$MESS ['BC_GROUPS'] = "Blog groups";
$MESS ['BLOG_TITLE'] = "Blogs";
$MESS ['BLOG_CREATE_BLOG'] = "Create your Blog";
$MESS ['BC_NEW_POSTS'] = "New";
$MESS ['BC_POPULAR_POSTS'] = "Popular";
$MESS ['BC_COMMENTED_POSTS'] = "Most commented";
$MESS ['BC_NEW_POSTS_MES'] = "New posts";
$MESS ['BC_POPULAR_POSTS_MES'] = "Popular posts";
$MESS ['BC_COMMENTED_POSTS_MES'] = "Most commented posts";
$MESS ['BC_SEARCH_TAG'] = "Tag cloud";
$MESS ['BC_ALL_POSTS'] = "View All Posts";
$MESS ['BC_ALL_BLOGS'] = "View All Blogs";
?>