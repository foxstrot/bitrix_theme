<?
$MESS ['SEARCH_LABEL'] = "Search:";
?>
