<?
$MESS["CATALOG_BUY"] = "Buy";
$MESS["CATALOG_ADD"] = "Add to cart";
$MESS["CATALOG_NOT_AVAILABLE"] = "(not available from stock)";
$MESS["CATALOG_TITLE"] = "Title";
$MESS["CT_BCS_ELEMENT_DELETE_CONFIRM"] = "All the information linked to this record will be deleted. Continue anyway?";
?>