<?
$MESS ['SEARCH_FONT_MAX'] = "Largest font size (px)";
$MESS ['SEARCH_FONT_MIN'] = "Smallest font size (px)";
$MESS ['SEARCH_COLOR_OLD'] = "Latest tag color (ex. \"FEFEFE\")";
$MESS ['SEARCH_COLOR_NEW'] = "Earliest tag color (ex. \"C0C0C0\")";
$MESS ['SEARCH_PERIOD_NEW_TAGS'] = "Consider tag new during (days)";
$MESS ['SEARCH_SHOW_CHAIN'] = "Display breadcrumb navigation.";
$MESS ['SEARCH_COLOR_TYPE'] = "Use gradient colors";
$MESS ['SEARCH_WIDTH'] = "Tag cloud width (ex. \"100%\", \"100px\", \"100pt\" or \"100in\")";
?>