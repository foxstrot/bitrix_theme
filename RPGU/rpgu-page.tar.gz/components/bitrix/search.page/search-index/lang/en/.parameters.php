<?
$MESS["SEARCH_FONT_MAX"] = "Largest font size (px)";
$MESS["SEARCH_FONT_MIN"] = "Smallest font size (px)";
$MESS["SEARCH_COLOR_OLD"] = "Latest tag colour (ex. \"FEFEFE\")";
$MESS["SEARCH_COLOR_NEW"] = "Earliest tag colour (ex. \"C0C0C0\")";
$MESS["SEARCH_CNT"] = "By frequency";
$MESS["SEARCH_COLOR_TYPE"] = "Use gradient colors";
$MESS["SEARCH_NAME"] = "By name";
$MESS["SEARCH_PAGE_ELEMENTS"] = "Number of tags";
$MESS["SEARCH_PERIOD"] = "Search tags within (days)";
$MESS["SEARCH_PERIOD_NEW_TAGS"] = "Consider tag new during (days)";
$MESS["SEARCH_TAGS_INHERIT"] = "Narrow search area";
$MESS["SEARCH_WIDTH"] = "Tag cloud width (ex. \"100%\", \"100px\", \"100pt\" or \"100in\")";
$MESS["SEARCH_URL_SEARCH"] = "Path to search page (relative to site root)";
$MESS["SEARCH_SHOW_CHAIN"] = "Display breadcrumb navigation";
$MESS["SEARCH_SORT"] = "Rank tags";
$MESS["TP_BSP_USE_SUGGEST"] = "Show search phrase prompts";
$MESS["TP_BSP_SHOW_RATING"] = "Show ratings";
$MESS["TP_BSP_PATH_TO_USER_PROFILE"] = "User profile path template";
$MESS["TP_BSP_SHOW_RATING_CONFIG"] = "default";
$MESS["TP_BSP_RATING_TYPE"] = "Rating buttons design";
$MESS["TP_BSP_RATING_TYPE_CONFIG"] = "default";
$MESS["TP_BSP_RATING_TYPE_STANDART_TEXT"] = "Like/Unlike (text)";
$MESS["TP_BSP_RATING_TYPE_STANDART_GRAPHIC"] = "Like/Unlike (image)";
$MESS["TP_BSP_RATING_TYPE_LIKE_TEXT"] = "Like (text)";
$MESS["TP_BSP_RATING_TYPE_LIKE_GRAPHIC"] = "Like (image)";
?>